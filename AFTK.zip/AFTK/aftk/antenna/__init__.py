#  -*- coding: utf-8 -*-
"""
Author: Rafael R. L. Benevides
"""

from .eigenantennas import get_eigenantennas, directivity